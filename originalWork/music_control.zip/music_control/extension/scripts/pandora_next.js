document.getElementsByClassName("skipButton")[0].firstChild.click();
