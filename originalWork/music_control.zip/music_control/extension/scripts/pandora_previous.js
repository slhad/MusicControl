// NO-OP. Pandora doesn't have a concept of back. Just next.
