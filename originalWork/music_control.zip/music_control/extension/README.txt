The Music Control project was created by Christian Cantrell:
https://plus.google.com/u/0/113556260101951952093/about

Icon by Ryan Oksenhorn for thenounproject.com:
http://thenounproject.com/noun/music/#icon-No928
